// main.js - Proyecto Final: Simulador 3D
// -------------------------------------------------------------
// Este script controla todo el sistema 3D: escena, materiales,
// iluminación, sombreado, texturas, transformaciones y animación.
// Se conecta con los botones y sliders del HTML para actualizar
// el modelo 3D en tiempo real.
// -------------------------------------------------------------


// -----------------------------
// 1. CONFIGURACIÓN PRINCIPAL
// -----------------------------

const container = document.getElementById("canvas-container"); // Div donde se renderiza el canvas 3D
const scene = new THREE.Scene(); // Escena donde se colocan los objetos

// Cámara que define qué parte de la escena será visible
const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
camera.position.set(0, 0, 8); // Posición inicial de la cámara alejándose del objeto

// Renderizador WebGL (motor de dibujo en pantalla)
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(container.clientWidth, container.clientHeight);
renderer.shadowMap.enabled = true; // Habilita cálculo de sombras
container.appendChild(renderer.domElement); // Inserta el canvas en la página



// -----------------------------
// 2. SISTEMA DE ILUMINACIÓN
// -----------------------------

// Luz ambiental: ilumina toda la escena suavemente
const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
scene.add(ambientLight);

// Luz direccional: simula al sol, produce sombras
const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
dirLight.position.set(5, 10, 7);
dirLight.castShadow = true;
scene.add(dirLight);

// Luz puntual: fuente luminosa localizada, definida con color rojo para mayor contraste
const pointLight = new THREE.PointLight(0xff0000, 1.5, 10);
pointLight.position.set(2, 2, 2);
scene.add(pointLight);

// Esfera visible que indica al usuario dónde está la luz puntual
const sphereSize = 0.2;
const pointLightHelper = new THREE.Mesh(
    new THREE.SphereGeometry(sphereSize, 16, 16),
    new THREE.MeshBasicMaterial({ color: 0xff0000 })
);
scene.add(pointLightHelper);



// ------------------------------------------------------------
// 3. CONTROL DE RELLENO (COLORES, GRADIENTE Y TEXTURAS)
// ------------------------------------------------------------

// Asigna color sólido mediante material Phong (con brillos)
window.setColorHomogeneo = function(colorHex) {
    currentMesh.material = new THREE.MeshPhongMaterial({
        color: colorHex,
        shininess: 40
    });
    currentMesh.material.needsUpdate = true;
};

let degradadoActivo = false;

// Activa o desactiva el degradado generado por CanvasTexture
window.toggleDegradado = function() {
    degradadoActivo = !degradadoActivo;

    if (degradadoActivo) {
        currentMesh.material = new THREE.MeshBasicMaterial({ map: textureGradient }); // Activa textura degradada
    } else {
        currentMesh.material = new THREE.MeshPhongMaterial({ color: 0xffffff, shininess: 60 }); // Regresa a material estándar
    }

    currentMesh.material.needsUpdate = true;
};



// ------------------------------------------------------------
// Texturas cargadas desde imágenes externas
// ------------------------------------------------------------

const loader = new THREE.TextureLoader();
const texturas = [
    loader.load("textura1.jpg"),
    loader.load("textura2.jpg"),
    loader.load("textura3.jpg"),
    loader.load("textura4.jpg"),
    loader.load("textura5.jpg")
];

window.setTexture = function(id) {
    currentMesh.material.map = texturas[id]; // Asigna textura a la superficie
    currentMesh.material.needsUpdate = true;
};



// ------------------------------------------------------------
// 4. TÉCNICAS DE SOMBREADO
// ------------------------------------------------------------
// Controla el material dependiendo del botón seleccionado

window.setShading = function(type) {
    if (!currentMesh) return;
    let mat;

    switch(type) {

        case "constante":  // No reacciona a luces
            mat = new THREE.MeshBasicMaterial({
                color: currentMesh.material.color,
                map: currentMesh.material.map
            });
            break;

        case "gouraud":  // Iluminación suave por vértices
            mat = new THREE.MeshLambertMaterial({
                color: currentMesh.material.color,
                map: currentMesh.material.map
            });
            break;

        case "phong":  // Brillo especular más definido
            mat = new THREE.MeshPhongMaterial({
                color: currentMesh.material.color,
                map: currentMesh.material.map,
                shininess: 80,
                specular: 0xffffff
            });
            break;

        case "fractal": // Material usando ruido aleatorio como textura
            mat = new THREE.MeshPhongMaterial({
                map: textureFractal,
                shininess: 20
            });
            break;
    }

    // Mantiene flags activados como Wireframe y Flat
    mat.wireframe = document.getElementById("check-wire").checked;
    mat.flatShading = document.getElementById("check-flat").checked;

    mat.needsUpdate = true;
    currentMesh.material = mat;
};

// Actualiza solo wireframe o flat shading sin cambiar material completo
window.applyShadingFlags = function() {
    if (!currentMesh) return;
    const mat = currentMesh.material;
    mat.wireframe = document.getElementById("check-wire").checked;
    mat.flatShading = document.getElementById("check-flat").checked;
    mat.needsUpdate = true;
};



// ------------------------------------------------------------
// GENERADORES DE TEXTURA (SIN IMÁGENES – AUTOCREADAS)
// ------------------------------------------------------------

// Textura degradada creada mediante canvas
function generarDegradado() {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');

    const grd = ctx.createLinearGradient(0, 0, 0, 256);
    grd.addColorStop(0, '#00ffff');
    grd.addColorStop(1, '#ff00ff');

    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, 256, 256);

    return new THREE.CanvasTexture(canvas);
}

// Textura fractal aleatoria tipo ruido
function generarFractal() {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    const imgData = ctx.createImageData(512, 512);
    for (let i = 0; i < imgData.data.length; i += 4) {
        const c = Math.random() * 255; // Tonalidad gris aleatoria
        imgData.data[i] = c;
        imgData.data[i+1] = c;
        imgData.data[i+2] = c;
        imgData.data[i+3] = 255;
    }
    ctx.putImageData(imgData, 0, 0);

    return new THREE.CanvasTexture(canvas);
}



// ------------------------------------------------------------
// 5. MODELADO 3D Y CREACIÓN DE OBJETOS
// ------------------------------------------------------------

let currentMesh; // Objeto actual en escena
let geometryType = 'cubo'; // Geometría inicial activa

// Texturas listas al iniciar
const textureGradient = generarDegradado();
const textureFractal  = generarFractal();

// Crea el objeto seleccionado desde los botones
function crearObjeto(tipo) {
    if (currentMesh) scene.remove(currentMesh); // Si ya existe uno, se elimina antes

    let geometry;
    switch(tipo) {
        case 'cubo':     geometry = new THREE.BoxGeometry(2, 2, 2); break;
        case 'esfera':   geometry = new THREE.SphereGeometry(1.5, 32, 32); break;
        case 'cilindro': geometry = new THREE.CylinderGeometry(1, 1, 3, 32); break;
        case 'toro':     geometry = new THREE.TorusKnotGeometry(1, 0.3, 100, 16); break;
    }
    
    // Material inicial Phong para destacar iluminación
    const material = new THREE.MeshPhongMaterial({ color: 0x00aaff, shininess: 100 });

    currentMesh = new THREE.Mesh(geometry, material);
    currentMesh.castShadow = true;
    currentMesh.receiveShadow = true;
    scene.add(currentMesh);

    // Reinicio visual de sliders al cambiar objeto
    document.getElementById('rotX').value = 0;
    document.getElementById('scale').value = 1;
}

// Objeto inicial en escena
crearObjeto('cubo');



// ------------------------------------------------------------
// 6. CONEXIÓN ENTRE HTML Y JAVASCRIPT
// ------------------------------------------------------------

// Cambia geometría desde botones
window.cambiarGeometria = function(tipo) {
    geometryType = tipo;
    crearObjeto(tipo);
    window.cambiarMaterial(); // Reaplica últimos parámetros usados
};

// Controles de transformación (rotación/posición/escala)
function updateTransforms() {
    if(!currentMesh) return;

    currentMesh.rotation.x = document.getElementById('rotX').value;
    currentMesh.rotation.y = document.getElementById('rotY').value;
    currentMesh.rotation.z = document.getElementById('rotZ').value;

    currentMesh.position.x = document.getElementById('posX').value;
    currentMesh.position.y = document.getElementById('posY').value;
    currentMesh.position.z = document.getElementById('posZ').value;

    const s = document.getElementById('scale').value;
    currentMesh.scale.set(s, s, s);
}

// Muestra valores numéricos junto al slider
window.updateSliderValue = function(id) {
    const slider = document.getElementById(id);
    const label = document.getElementById(id + "-val");
    label.textContent = Number(slider.value).toFixed(2);
};



// ------------------------------------------------------------
// 7. CONTROLES DE ILUMINACIÓN
// ------------------------------------------------------------

// Activa / desactiva luces desde HTML
window.updateLights = function() {
    ambientLight.visible = document.getElementById('light-ambient').checked;
    dirLight.visible     = document.getElementById('light-dir').checked;
    pointLight.visible   = document.getElementById('light-point').checked;
    pointLightHelper.visible = pointLight.visible;
};

// Mover la luz puntal con slider
window.movePointLight = function() {
    const val = document.getElementById('light-move').value;
    pointLight.position.x = val;
    pointLightHelper.position.x = val;
};



// ------------------------------------------------------------
// 8. LOOP DE ANIMACIÓN - Motor del renderizado
// ------------------------------------------------------------

function animate() {
    requestAnimationFrame(animate); // Ciclo infinito de dibujo
    updateTransforms(); // Los sliders se leen cada frame
    renderer.render(scene, camera); // Render actualizado
}

// Ajuste automático cuando se cambia tamaño de ventana
window.addEventListener('resize', () => {
    const w = container.clientWidth;
    const h = container.clientHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
});

// Ejecuta animación
animate();
