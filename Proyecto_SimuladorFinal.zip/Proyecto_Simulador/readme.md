Laboratorio 3D – Simulador Interactivo Web
Este proyecto es un simulador gráfico en Three.js que permite explorar conceptos básicos y avanzados de graficación en 3D.
El usuario puede manipular objetos, activar diferentes materiales, cambiar el tipo de iluminación y aplicar técnicas de sombreado 
en tiempo real mientras observa los resultados visuales dentro de la escena.
Objetivo del Proyecto
Crear una aplicación web donde se puedan:
✔ Visualizar objetos tridimensionales
✔ Modificar su relleno mediante color, degradado o textura
✔ Encender / apagar tipos de iluminación y mover la luz puntual
✔ Cambiar técnicas de sombreado (Phong, Gouraud, Fractal, etc.)
✔ Aplicar transformaciones espaciales sobre los modelos
Todo esto respondiendo de forma inmediata, con una interfaz sencilla y funcional.
Funcionalidades Implementadas
Sección	                  Características del Simulador	                        Evidencia en código
Objetos 3D	              Cubo, esfera, cilindro y toroide	                    crearObjeto(), cambiarGeometria()
Relleno (4.1)	          Color homogéneo, degradado ON/OFF, texturas	        setColorHomogeneo(), toggleDegradado(), setTexture()
Iluminación (4.2)	      Luz ambiental, direccional y puntual móvil	        updateLights(), movePointLight()
Sombreado (4.3)	          Constante, Gouraud, Phong, Fractal + Wireframe +Flat	setShading(), applyShadingFlags()
Transformaciones (4.4)	  Rotación XYZ, traslación XYZ, escalado	            updateTransforms()

Cómo usar el simulador
1.	Elige un objeto 3D desde el panel izquierdo
2.	Selecciona un tipo de color, textura o degradado
3.	Activa o desactiva luces para comparar sombras y brillos
4.	Cambia el método de sombreado para notar diferencias visuales
5.	Usa los sliders de transformación para moverlo o rotarlo en el espacio
Los cambios se aplican instantáneamente, permitiendo experimentación libre.
Integrantes
Nombre	                     Rol dentro del proyecto
Luis Rosales de Jesús	     Desarrollo principal en Three.js
Luis Humberto Sosa Patricio	 UI y estilo CSS
Leonel Hernández Rodríguez	 Documentación e informe técnico

Tecnologías
Tecnología	     Uso dentro del proyecto
Three.js	     Renderizado 3D principal
HTML5	         Estructura visual y contenedores
CSS3	         Diseño tipo laboratorio oscuro
JavaScript ES6	 Lógica, interacción y animaciones

Instalación y Ejecución
Este proyecto no requiere dependencias. Solo necesitas:
index.html
main.js
style.css
texturas/
Puedes abrirlo con doble clic sobre index.html o usar Live Server para mejor rendimiento.
